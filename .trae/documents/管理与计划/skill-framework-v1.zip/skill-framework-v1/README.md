# Skill Framework v1（通用项目：脑爆→规格→设计→分步→开发→验收）

**界面语言**：中文（zh-CN）  
**默认技术栈**：Web=Next.js；硬件=Raspberry Pi Pico（MicroPython）  
**覆盖类型**：Web / 硬件 / Kaggle建模 / 课程融合

## 1. 全局目标
- 面向 10–18 岁学生，通过“脑爆 → 收敛 → 分步交付”的统一流程，完成任意类型项目。
- 强制**结构化工件（Artifacts）**串联 Skill，保证可评测、可回放、可返工。

## 2. 全局硬约束（所有 Skill 必须遵守）
1) **结构化输出**：除非 Skill 明确允许自由文本，否则最终输出必须是 JSON（严格匹配对应 schema）。  
2) **复杂度预算**：必须依据 `time_budget` 自动裁剪：  
   - 2h：只做 MVP（<=2 里程碑，<=6 steps）  
   - 6h：MVP + 1 个增强点（<=3 里程碑，<=12 steps）  
   - 12h：MVP + 2 个增强点（<=4 里程碑，<=18 steps）  
3) **教育性优先**：默认开启 quiz（反问机制），但 quiz 不阻塞流程（答错也能继续，只触发解释/提示）。  
4) **变体机制**：同一个 Skill 根据 `track_selected` 输出不同 variant 内容，但字段结构保持一致（工件 schema 不变）。

## 3. 统一工件（Artifacts）
固定 6 个工件（文件名固定）：
- `artifacts/templates/project_brief.json`
- `artifacts/templates/constraints.json`
- `artifacts/templates/track_plan.json`
- `artifacts/templates/design.json`
- `artifacts/templates/step_plan.json`
- `artifacts/templates/evaluation.json`

## 4. Skill 流程（8 个核心 Skill）
1) Brainstorm Studio（需求脑爆工作室）  
2) Idea → Spec（项目翻译官）  
3) Scope Cutter（范围裁剪器）  
4) Track Router（轨道选择与技术卡片）  
5) Designer（设计器）  
6) Task Decomposer（分步指令生成器）  
7) Coder Coach（增量开发教练）  
8) Evaluator & Showcase（验收与展示）

## 5. 使用方式（建议）
- 严格按顺序执行 Skill。
- 每个 Skill 读入上一步的工件，产出新的工件；若不通过 rubric，返工补齐。
- 题库与提问库在 `libraries/` 目录。
