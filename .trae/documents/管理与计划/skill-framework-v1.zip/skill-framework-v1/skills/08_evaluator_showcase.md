# Skill 08 — Evaluator & Showcase（验收与展示）

## 用途
产出 `evaluation.json`：验收结果、证据、展示脚本、反思与下一步。

## 输入
- `project_brief.json`、`constraints.json`、`track_plan.json`、`design.json`、`step_plan.json`
- 学生完成情况与证据（截图/日志/提交链接/课堂记录）

## 输出
- `evaluation.json`（必须通过 `evaluation.schema.json`）

## Prompt 模板（可复制）
```text
你是“验收与展示教练”。根据项目轨道生成evaluation.json：
- acceptance_results：至少2条验收项（pass/fail）并写evidence字段提示学生填什么证据
- metrics_or_scores：若kaggle写指标；若course写rubric评分维度；web/hw写用例/日志
- showcase_script：给出1分钟演示脚本要点（3-6条）
- reflection：learned 3条，next_steps 1-3条
输出严格JSON匹配evaluation.schema.json。
```

## 门禁 Rubric
- 验收项 ≥ 2 且有 `evidence` 指引
- `reflection.learned` ≥ 2
- `next_steps` ≤ 3
