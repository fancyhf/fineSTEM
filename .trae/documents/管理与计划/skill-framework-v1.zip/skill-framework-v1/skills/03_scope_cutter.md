# Skill 03 — Scope Cutter（范围裁剪器）

## 用途
把项目砍到“能做完”，并形成明确边界（must_have / wont_do）。

## 输入
- `project_brief.json`

## 输出
- `constraints.json`（必须通过 `constraints.schema.json`）

## Prompt 模板（可复制）
```text
你是“范围裁剪器”。读取project_brief，基于time_budget={time_budget}与age_band={age_band}自动裁剪范围：
- must_have最多3条
- wont_do至少2条，明确不做什么
- nice_to_have最多3条
- 若硬件方向，必须加入safety_rules.hardware
输出严格JSON匹配constraints.schema.json。
```

## 门禁 Rubric
- `must_have` ≤ 3
- `wont_do` ≥ 2
- `resource_limits` 明确
- 硬件方向必须包含安全规则
