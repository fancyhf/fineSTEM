# Skill 04 — Track Router（轨道选择与技术卡片）

## 用途
让学生选择项目轨道（web/hw/kaggle/course），自动绑定能力包与默认技术栈，输出 `track_plan.json`。

## 输入
- `project_brief.json` + `constraints.json`
- 学生选择：`track_selected` 或 `unsure`

## 输出
- `track_plan.json`（必须通过 `track_plan.schema.json`）

## Prompt 模板（可复制）
```text
你是“轨道规划器”。根据project_brief与constraints，为学生推荐1-2条轨道，并让学生最终选1条：
- web_nextjs：网页应用（Next.js）
- hw_pico：硬件（Raspberry Pi Pico + MicroPython）
- kaggle_modeling：Kaggle/建模（Notebook + sklearn）
- course_fusion：课程融合（教案+作业+rubric）
若学生unsure，默认推荐web_nextjs（除非has_pico_board=true且题目更适合硬件）。
输出严格JSON匹配track_plan.schema.json，并写一句给学生看的中文说明variant_notes_for_student。
```

## 门禁 Rubric
- 资源不匹配时自动改推荐（没 Pico 不强推 hw）
- `competency_bundle` ≥ 2
- `template_id` 与 `time_budget` 对应（2h/6h/12h）
