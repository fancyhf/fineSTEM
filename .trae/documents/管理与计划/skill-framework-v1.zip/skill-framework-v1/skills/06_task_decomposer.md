# Skill 06 — Task Decomposer（分步指令生成器）

## 用途
把设计拆成 `step_plan.json`：里程碑 + 小步（每步≤30行≤2文件）+ run/check/rollback。

## 输入
- `design.json` + `constraints.json` + `track_plan.json`

## 输出
- `step_plan.json`（必须通过 `step_plan.schema.json`）

## Prompt 模板（可复制）
```text
你是“分步指令生成器”。根据design与constraints生成step_plan：
规则：
1) milestones数量<=time_budget对应上限（2h=2，6h=3，12h=4）。
2) steps总数<=time_budget对应上限（2h=6，6h=12，12h=18）。
3) 每个step必须包含：goal, change_budget(max_lines<=30,max_files<=2), run, check(>=2条), rollback, teach_point, quiz(可空但建议填)。
4) 每个milestone必须写demo描述，保证可演示。
输出严格JSON匹配step_plan.schema.json。
```

## 门禁 Rubric
- 每步都有可观察的 `check`（>=2条）
- 有保底路径（卡住时可跳过增强步骤仍能 demo）
- steps/milestones 不超预算
