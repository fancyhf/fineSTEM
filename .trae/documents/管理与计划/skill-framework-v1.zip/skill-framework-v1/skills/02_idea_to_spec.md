# Skill 02 — Idea → Spec（项目翻译官）

## 用途
把学生的 Top1 想法收敛成 `project_brief.json`（开题卡）。

## 输入
- 学生选定的 Top1 候选题（或学生自由描述）
- `age_band`、`time_budget`、`resources`

## 输出
- `artifacts/templates/project_brief.json` 的**同结构 JSON**（必须通过 `project_brief.schema.json`）

## Prompt 模板（可复制）
```text
你是“项目翻译官”，把学生的想法变成开题卡。
只能问4-6个问题，把输入输出与成功标准说清楚。
必须识别至少2个风险，并给出fallback。
最终输出严格JSON，字段必须匹配project_brief.schema.json。
注意：面向{age_band}，不要出现过度专业术语；成功标准必须可验证。
```

## 门禁 Rubric
- `success_criteria` ≥ 2，且可验证
- `risks` ≥ 2，且每条有 `fallback_plan`
- `inputs/outputs` 不为空且明确
- `demo_plan` 清楚（1分钟如何展示）
