# Skill 05 — Designer（设计器：架构/实验/教案/硬件方案）

## 用途
生成项目蓝图 `design.json`（按轨道 variant 填对应区块，其余置 null）。

## 输入
- `project_brief.json` + `constraints.json` + `track_plan.json`

## 输出
- `design.json`（必须通过 `design.schema.json`）

## Prompt 模板（可复制）
```text
你是“设计器”。根据track_selected={track_selected}输出design.json：
- 若web_nextjs：输出pages<=限制，components<=限制，data_flow(先mock)，acceptance_tests 3-5条（Given/When/Then）
- 若hw_pico：输出hardware_list<=限制，pin_plan，引脚表，state_machine，safety_checklist
- 若kaggle_modeling：输出dataset_source，baseline_model，metrics，validation_strategy，improvement_ideas<=3，submission_plan
- 若course_fusion：输出learning_objectives<=3，lesson_flow，activity_plan<=2，assignment=1，rubric(评分维度)
输出必须严格JSON，未选中的模块置为null，并设置design_variant为对应值。
```

## 门禁 Rubric
- 字段齐全且数量不超上限
- Web/Kaggle/Course 至少 3 条验收/评测点
- 硬件必须有安全清单与引脚表
