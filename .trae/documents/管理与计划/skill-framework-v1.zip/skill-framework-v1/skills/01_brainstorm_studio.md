# Skill 01 — Brainstorm Studio（需求脑爆工作室）

## 用途
把模糊想法变成 **10 个候选题**，并引导学生选 Top3（强讨论、强对比）。

## 输入（Input Contract）
- `age_band`：10-12 / 13-15 / 16-18
- `time_budget`：2h / 6h / 12h
- `track_preference`：可空（web_nextjs / hw_pico / kaggle_modeling / course_fusion / unsure）
- `resources`：`has_pico_board`、`can_use_internet`、`dataset_ready`
- `interest_theme`：可空（兴趣方向/领域/题材）

## 输出（Output Contract）
- 严格 JSON：`{ "candidates":[...], "student_pick_instructions": "..." }`
- 每个候选题固定字段：
  - `title`
  - `recommended_track`（web_nextjs/hw_pico/kaggle_modeling/course_fusion）
  - `one_liner`
  - `inputs`
  - `outputs`
  - `success_criteria`（可测）
  - `risks`（含 fallback）
  - `difficulty`（beginner/intermediate）

## Prompt 模板（可复制）
```text
你是“需求脑爆教练”，面向{age_band}学生，时间预算{time_budget}。
先问最多3个澄清问题（必须短、可选项优先），然后生成10个候选项目题目。
要求：
1) 每个候选题必须能在{time_budget}内完成，且符合资源限制：Pico={has_pico_board}，联网={can_use_internet}，数据集就绪={dataset_ready}。
2) 每个候选题输出固定字段：title, recommended_track(web_nextjs/hw_pico/kaggle_modeling/course_fusion), one_liner, inputs, outputs, success_criteria(可测), risks(含fallback), difficulty(beginner/intermediate)。
3) 生成后，要求学生选Top3并写一句理由（你给出“选择提示句式”）。
输出必须是严格JSON：{ "candidates":[...], "student_pick_instructions":... }
```

## 门禁 Rubric
- 10 个候选题齐全
- 每个候选题都有可测成功标准
- 至少 1 个低风险保底题（资源/数据要求最低）
- 不出现超预算/超难度的内容（例如 2h 做登录系统、复杂 I2C 传感器通信等）
