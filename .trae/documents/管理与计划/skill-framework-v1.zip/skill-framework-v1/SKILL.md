# SKILL.md — Skill Framework v1（通用项目：脑爆→规格→设计→分步→开发→验收）

> 这是一个“通用 Skill 体系规格包”，面向 10–18 岁学生，支持：
> - Web（Next.js）
> - 硬件（Raspberry Pi Pico + MicroPython）
> - Kaggle/建模（Notebook + sklearn）
> - 课程融合（教案 + 作业 + Rubric）

## 目录导航
- `README.md`：全局规则与总体说明（中文界面）
- `routing.yml`：学生选择 → track/variant/runner/模板 映射规则
- `skills/`：8 个核心 Skill 的规格文件（Prompt 模板 + 输入/输出 + Rubric）
- `artifacts/templates/`：6 个通用工件（Artifacts）JSON 空模板
- `artifacts/schemas/`：6 个工件 JSON Schema（用于校验/门禁）
- `libraries/`：题库与引导提问库

## 运行顺序（建议固定）
1. `skills/01_brainstorm_studio.md`
2. `skills/02_idea_to_spec.md`
3. `skills/03_scope_cutter.md`
4. `skills/04_track_router.md`
5. `skills/05_designer.md`
6. `skills/06_task_decomposer.md`
7. `skills/07_coder_coach.md`
8. `skills/08_evaluator_showcase.md`

## 工件（Artifacts）
流程中会依次生成并更新以下 6 个 JSON 工件（结构在 templates 与 schemas 中定义）：
- `project_brief.json`
- `constraints.json`
- `track_plan.json`
- `design.json`
- `step_plan.json`
- `evaluation.json`

## 题库（Topic Library）
见 `libraries/topic_library_*.md`，Brainstorm Studio 可优先从题库抽样再做变体生成。
